﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public static SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\rudra\WindowsFormsApplication1\WindowsFormsApplication1\bin\Debug\Database1.mdf;Integrated Security=True;User Instance=True");
        int tr = 0;
        int rp = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            loaddata();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String sql = "insert into stud values('"+textBox1.Text+"','"+textBox2.Text+"')";
            SqlDataAdapter da = new SqlDataAdapter(sql,cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            clear();
            loaddata();
        }
        public void clear()
        {
            textBox1.Text = textBox2.Text = "";
            textBox1.Focus();
        }
        public void loaddata()
        {
            String sql = "select * from stud";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void button2_Click(object sender, EventArgs e)
        {

            String sql = "update stud set name='"+textBox2.Text+"' where id='"+textBox1.Text+"'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            clear();
            loaddata();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String sql = "delete from stud where id='" + textBox1.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            clear();
            loaddata();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String sql = "select * from stud";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            //tr = dt.Rows.Count - 1;
            rp = 0;
            textBox1.Text = dt.Rows[rp][0].ToString();
            textBox2.Text = dt.Rows[rp][1].ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            String sql = "select * from stud";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            tr = dt.Rows.Count - 1;
            rp = tr;
            textBox1.Text = dt.Rows[rp][0].ToString();
            textBox2.Text = dt.Rows[rp][1].ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            String sql = "select * from stud";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            rp--;
          
            if (rp < 0)
            {
                MessageBox.Show("first record");
            }
            else {
     
                textBox1.Text = dt.Rows[rp][0].ToString();
                textBox2.Text = dt.Rows[rp][1].ToString();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            String sql = "select * from stud";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            rp++;
            tr = dt.Rows.Count - 1;
            if (rp > tr)
            {
                MessageBox.Show("last record");
              
            }
            else {
                textBox1.Text = dt.Rows[rp][0].ToString();
                textBox2.Text = dt.Rows[rp][1].ToString();
            }
        }

    

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox3.Text != "")
            {
                String sql = "select * from stud where id='" + textBox3.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    textBox1.Text = dt.Rows[0][0].ToString();
                    textBox2.Text = dt.Rows[0][1].ToString();
                }
            }

        }
    }
}
